from django.db import models

# Create your models here.

class User(models.Model):
    Username = models.CharField(max_length=30)
    User_id = models.IntegerField(max_length=100)
    About = models.CharField(max_length = 500)
    
    def __str__(self):
        return self.Username

class Post(models.Model):
    User = models.OneToOneField(User,on_delete=models.CASCADE)
    Post = models.ManyToOneRel(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    content = models.CharField(max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.content
    
class Comment(models.Model):
    User = models.ForeignKey(User,on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    comment = models.CharField(max_length=500)
    commented_at = models.DateTimeField(auto_now_add=True)

class Like(models.Model):
    User = models.ForeignKey(User,on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

class Dislike(models.Model):
    User = models.ForeignKey(User,on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)