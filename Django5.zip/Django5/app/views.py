from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Post

def create_post(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        
        # Basic validation (you can enhance this)
        if title and content:
            Post.objects.create(title=title, content=content)
            return redirect('post_list')
        else:
            return HttpResponse("Both title and content are required!", status=400)
    
    return render(request, 'create_post.html')